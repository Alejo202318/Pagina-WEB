<?php
$destino = "reclamos@sbytechnology.com";

// Recoge y limpia los datos del formulario
function limpiar($campo) {
    return htmlspecialchars(strip_tags(trim($campo)), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}
$nombre   = isset($_POST['nombre'])   ? limpiar($_POST['nombre']) : '';
$email    = isset($_POST['email'])    ? limpiar($_POST['email']) : '';
$telefono = isset($_POST['telefono']) ? limpiar($_POST['telefono']) : '';
$detalle  = isset($_POST['detalle'])  ? limpiar($_POST['detalle']) : '';

// Validación básica
if ($nombre && $email && $telefono && $detalle) {
    // Validación de teléfono: solo 9 dígitos numéricos
    if (!preg_match('/^\d{9}$/', $telefono)) {
        echo "<script>alert('El teléfono debe tener exactamente 9 dígitos, solo números.'); window.history.back();</script>";
        exit;
    }

    // Guarda en archivo CSV
    $csv_file = 'reclamaciones.csv';
    $fecha = date('Y-m-d H:i:s');
    $csv_line = "\"$fecha\",\"$nombre\",\"$email\",\"$telefono\",\"" . str_replace('"','""',$detalle) . "\"\n";
    if(!file_exists($csv_file)) {
        file_put_contents($csv_file, "\"Fecha\",\"Nombre\",\"Email\",\"Teléfono\",\"Detalle\"\n", FILE_APPEND);
    }
    file_put_contents($csv_file, $csv_line, FILE_APPEND);

    // Construye mensaje solo texto plano (no HTML)
    $asunto = "Nuevo Reclamo - Libro de Reclamaciones SBYTechnology";
    $mensaje = "Nuevo reclamo recibido:\n\n";
    $mensaje .= "Nombre: $nombre\n";
    $mensaje .= "Email: $email\n";
    $mensaje .= "Teléfono: $telefono\n";
    $mensaje .= "Detalle: $detalle\n";
    $mensaje .= "Fecha: $fecha\n";

    // Cabeceras básicas
    $cabeceras  = "From: SBYTechnology <$destino>\r\n";
    $cabeceras .= "Reply-To: $destino\r\n";

    // Envía el correo al administrador
    $ok = mail($destino, $asunto, $mensaje, $cabeceras);

    // Redirige a la página de gracias si todo OK
    if ($ok) {
        header("Location: gracias-reclamo.html");
        exit;
    } else {
        echo "<script>alert('Hubo un error al enviar el reclamo. Intenta nuevamente.'); window.history.back();</script>";
    }
} else {
    echo "<script>alert('Por favor, completa todos los campos obligatorios.'); window.history.back();</script>";
}
?>