<?php
// enviar-cotizacion.php
// Versión robusta para cotizaciones: saneamiento, cabeceras correctas, logging.

// Configuración: AJUSTA estos valores según tu hosting/dominio
$to = 'ventas@sbytechnology.com';        // destinatario final
$fromDomain = 'sbytechnology.com';       // dominio del sitio (debe coincidir)
$fromAddress = 'no-reply@' . $fromDomain;
$logFile = __DIR__ . '/mail_log_cotiza.txt';

// Obtener y sanear entradas
function clean($v) {
    return trim(htmlspecialchars(strip_tags($v), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'));
}
$nombre    = clean($_POST['nombre'] ?? '');
$email     = clean($_POST['email'] ?? '');
$productos = clean($_POST['productos'] ?? '');
$detalle   = clean($_POST['detalle'] ?? '');

// Validación mínima
$errors = [];
if ($nombre === '') $errors[] = 'Nombre requerido.';
if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Email inválido.';
if ($productos === '') $errors[] = 'Producto(s) de interés requerido.';

// Si hay errores, mostramos JSON (útil si usas AJAX) o HTML si se llama por submit normal
if (!empty($errors)) {
    if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['success' => false, 'errors' => $errors]);
    } else {
        echo "<h3>Errores:</h3><ul>";
        foreach ($errors as $e) echo "<li>$e</li>";
        echo "</ul><p><a href='javascript:history.back()'>Volver</a></p>";
    }
    exit;
}

// Construir asunto y cuerpo (texto plano y HTML)
$subject = 'Nueva cotización desde web - ' . ($productos ?: 'Sin producto');
$host = $_SERVER['HTTP_HOST'] ?? 'sitio';
$body_plain = "Nueva solicitud de cotización\n\n";
$body_plain .= "Nombre: $nombre\n";
$body_plain .= "Email: $email\n";
$body_plain .= "Productos: $productos\n\n";
$body_plain .= "Detalle:\n$detalle\n\n";
$body_plain .= "Enviado desde: $host - " . date('c') . "\n";

$body_html = "<html><body>";
$body_html .= "<h2>Nueva solicitud de cotización</h2>";
$body_html .= "<table cellpadding='6' style='font-size:1.05em;'>";
$body_html .= "<tr><td><strong>Nombre:</strong></td><td>" . htmlentities($nombre) . "</td></tr>";
$body_html .= "<tr><td><strong>Email:</strong></td><td>" . htmlentities($email) . "</td></tr>";
$body_html .= "<tr><td><strong>Productos:</strong></td><td>" . nl2br(htmlentities($productos)) . "</td></tr>";
$body_html .= "<tr><td><strong>Detalle:</strong></td><td>" . nl2br(htmlentities($detalle)) . "</td></tr>";
$body_html .= "</table>";
$body_html .= "<hr><small>Enviado desde $host - " . date('c') . "</small>";
$body_html .= "</body></html>";

// Cabeceras (usar From del propio dominio para mejorar entregabilidad)
$headers = [];
$headers[] = 'MIME-Version: 1.0';
$headers[] = 'Content-Type: text/html; charset=UTF-8';
$headers[] = 'From: SBYTechnology <' . $fromAddress . '>';
$headers[] = 'Reply-To: ' . $email;
$headers[] = 'X-Mailer: PHP/' . phpversion();
$headersString = implode("\r\n", $headers);

// Intento de envío con envelope-from (opcional -f)
$additionalParameters = '-f' . $fromAddress;
$mailOk = false;
try {
    $mailOk = mail($to, $subject, $body_html, $headersString, $additionalParameters);
} catch (Exception $e) {
    $mailOk = false;
}

// Registrar intento en log para depuración
$log  = "[" . date('Y-m-d H:i:s') . "] mail() returned: " . ($mailOk ? 'true' : 'false') . PHP_EOL;
$log .= "To: $to\nSubject: $subject\nHeaders:\n$headersString\n\nBody (plain):\n$body_plain\n";
$log .= "REMOTE_ADDR: " . ($_SERVER['REMOTE_ADDR'] ?? '') . "\n\n";
file_put_contents($logFile, $log, FILE_APPEND | LOCK_EX);

// Respuesta al usuario
if ($mailOk) {
    // si form se enviado vía AJAX, retornar JSON; si no, redirigir a gracias.html
    if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['success' => true, 'message' => '¡Cotización enviada!']);
        exit;
    } else {
        header('Location: gracias.html');
        exit;
    }
} else {
    // Mostrar mensaje de error y pedir revisar log
    if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['success' => false, 'message' => 'Error al enviar. Revisa el log en el servidor.']);
    } else {
        echo "<h3>Error enviando la cotización</h3>";
        echo "<p>Ocurrió un problema enviando el correo. Por favor intenta más tarde.</p>";
        echo "<p>Si eres el administrador, revisa el archivo de log: <code>$logFile</code></p>";
    }
    exit;
}
?>