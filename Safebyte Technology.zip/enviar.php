<?php
// Configuración
$destino = "contactos@sbytechnology.com";
$asunto  = "Nuevo mensaje desde el formulario web SBYTechnology";

// Recoge y sanitiza los datos
function limpiar($campo) {
    return htmlspecialchars(strip_tags(trim($campo)), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}
$nombre   = isset($_POST['nombre'])   ? limpiar($_POST['nombre']) : '';
$email    = isset($_POST['email'])    ? limpiar($_POST['email']) : '';
$telefono = isset($_POST['telefono']) ? limpiar($_POST['telefono']) : '';
$mensaje  = isset($_POST['mensaje'])  ? limpiar($_POST['mensaje']) : '';
$empresa  = isset($_POST['empresa'])  ? $_POST['empresa'] : ''; // honeypot

// Validaciones personalizadas
$errores = [];
if ($empresa !== '') {
    $errores[] = "¡Ups! Detectamos actividad sospechosa. Intenta de nuevo.";
}
if (!$nombre || !$email || !$telefono || !$mensaje) {
    $errores[] = "Por favor, rellena <b>todos</b> los campos.";
}
if (!preg_match('/^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]{3,50}$/u', $nombre)) {
    $errores[] = "El nombre debe contener solo letras y tener entre 3 y 50 caracteres.";
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errores[] = "Por favor ingresa un <b>correo electrónico válido</b>.";
}
// Validación de teléfono: solo 9 dígitos numéricos
if (!preg_match('/^\d{9}$/', $telefono)) {
    $errores[] = "El teléfono debe tener exactamente 9 dígitos, solo números.";
}
if (mb_strlen($mensaje) < 10) {
    $errores[] = "El mensaje debe ser más detallado (mínimo 10 caracteres).";
}

// Si hay errores, muestra mensaje personalizado y termina
if (!empty($errores)) {
    echo "<!DOCTYPE html>
    <html lang='es'><head>
      <meta charset='UTF-8'><meta name='viewport' content='width=device-width,initial-scale=1'>
      <title>Error en formulario</title>
      <style>
        body{background:#f9fafd;font-family:'Poppins',Arial,sans-serif;color:#182848;display:flex;align-items:center;justify-content:center;min-height:100vh;}
        .box{background:#fff;border-radius:12px;box-shadow:0 4px 24px #1e72b822;padding:32px 24px;text-align:center;}
        .box h2{color:#c2410c;}
        .box ul{text-align:left;margin:1em auto 0 auto;max-width:380px;}
        .box li{margin-bottom:8px;}
        .box a{color:#fff;background:#1e72b8;padding:10px 22px;border-radius:22px;text-decoration:none;display:inline-block;margin:20px 0 0 0;font-weight:600;}
        .box a:hover{background:#ffe764;color:#182848;}
      </style>
    </head>
    <body>
      <div class='box'>
        <h2>Corrige lo siguiente:</h2>
        <ul>";
    foreach ($errores as $e) echo "<li>".$e."</li>";
    echo "</ul>
        <a href='javascript:history.back()'>&larr; Volver al formulario</a>
      </div>
    </body></html>";
    exit;
}

// Construye el mensaje HTML para el administrador
$contenido = "
<html><body>
  <h2>Nuevo mensaje desde la web SBYTechnology</h2>
  <table cellpadding='6' style='font-size:1.08em;'>
    <tr><td><b>Nombre:</b></td><td>$nombre</td></tr>
    <tr><td><b>Email:</b></td><td>$email</td></tr>
    <tr><td><b>Teléfono:</b></td><td>$telefono</td></tr>
    <tr><td><b>Mensaje:</b></td><td>".nl2br($mensaje)."</td></tr>
  </table>
  <hr>
  <small>Este mensaje se envió desde el formulario web de SBYTechnology.</small>
</body></html>
";

// Cabeceras para HTML
$cabeceras  = "MIME-Version: 1.0\r\n";
$cabeceras .= "Content-type: text/html; charset=UTF-8\r\n";
$cabeceras .= "From: $nombre <$email>\r\n";
$cabeceras .= "Reply-To: $email\r\n";

// ENVÍA al administrador
$mail1 = mail($destino, $asunto, $contenido, $cabeceras);

// ENVÍA COPIA AL USUARIO
$asuntoUser = "Hemos recibido tu mensaje | SBYTechnology";
$contenidoUser = "
<html><body>
  <h2>¡Hola $nombre!</h2>
  <p>Gracias por contactarnos, hemos recibido tu mensaje y <b>pronto te responderemos</b>.</p>
  <p><b>Este es el resumen de tu envío:</b></p>
  <table cellpadding='6' style='font-size:1.06em;'>
    <tr><td><b>Nombre:</b></td><td>$nombre</td></tr>
    <tr><td><b>Email:</b></td><td>$email</td></tr>
    <tr><td><b>Teléfono:</b></td><td>$telefono</td></tr>
    <tr><td><b>Mensaje:</b></td><td>".nl2br($mensaje)."</td></tr>
  </table>
  <p style='margin-top:24px;'>Saludos,<br><b>SBYTechnology</b></p>
  <hr>
  <small>Este correo es solo informativo, no respondas a este mensaje.</small>
</body></html>
";
$cabecerasUser  = "MIME-Version: 1.0\r\n";
$cabecerasUser .= "Content-type: text/html; charset=UTF-8\r\n";
$cabecerasUser .= "From: SBYTechnology <no-reply@sbytechnology.com>\r\n";

// ENVÍA al usuario
$mail2 = mail($email, $asuntoUser, $contenidoUser, $cabecerasUser);

// Redirige si OK, muestra error si falla
if ($mail1 && $mail2) {
    header("Location: gracias.html");
    exit;
} else {
    echo "<!DOCTYPE html><html lang='es'><head><meta charset='UTF-8'><title>Error</title></head>
    <body style='font-family:Poppins,Arial,sans-serif;background:#f9fafd;text-align:center;padding-top:80px;'>
    <h2 style='color:#c2410c;'>Error enviando el mensaje. Intenta más tarde.</h2>
    <a href='javascript:history.back()' style='color:#fff;background:#1e72b8;padding:10px 22px;border-radius:22px;text-decoration:none;'>Volver al formulario</a>
    </body></html>";
}
?>